document.getElementById(form).addEventListener('submit', submitForm);
 
  